<?php 

    //MySQL or POO
//Connect to database
$conn = mysqli_connect('localhost','root','','ninja_pizza');

//check connection
if(!$conn){
    echo 'Connection Error: ' . mysqli_connect_error();
}

?>

