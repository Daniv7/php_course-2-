
    <footer class="section">
        <div class="center gray-text"> Copyright KU 2022 Pizza</div>
    </footer>
</body>



